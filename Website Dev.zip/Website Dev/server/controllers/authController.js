// controllers/authController.js (hardened, UI-compatible)
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const User = require('../models/User');
const LoginAttempt = require('../models/LoginAttempt');
const sendEmail = require('../utils/sendEmail');

const ACCESS_TTL = process.env.ACCESS_TTL || '2h';
const SALT_ROUNDS = 12;

function signToken(id) {
  return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: ACCESS_TTL });
}

function sanitizeUser(u) {
  return { id: u._id, username: u.username, email: u.email };
}

// Register a new user
exports.registerUser = async (req, res) => {
  try {
    const { username, email, password, repeatPassword } = req.body || {};

    // Basic validation
    if (!username || !email || !password) {
      return res.status(400).json({ success: false, message: 'Missing required fields.' });
    }
    if (repeatPassword !== undefined && password !== repeatPassword) {
      return res.status(400).json({ success: false, message: 'Passwords do not match.' });
    }
    if (String(username).length < 3 || String(username).length > 20) {
      return res.status(400).json({ success: false, message: 'Username must be 3–20 characters.' });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) {
      return res.status(400).json({ success: false, message: 'Please enter a valid email.' });
    }
    if (String(password).length < 8) {
      return res.status(400).json({ success: false, message: 'Password must be at least 8 characters.' });
    }

    const existing = await User.findOne({ $or: [{ username }, { email }] }).lean();
    if (existing) {
      return res.status(409).json({ success: false, message: 'Username or email already exists.' });
    }

    const hashed = await bcrypt.hash(password, SALT_ROUNDS);
    await User.create({ username, email, password: hashed });

    return res.status(201).json({ success: true, message: 'User registered successfully.' });
  } catch (err) {
    console.error('registerUser error:', err);
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// Login user (username OR email)
exports.loginUser = async (req, res) => {
  const { username, password } = req.body || {};
  const ip =
    (req.headers['x-forwarded-for'] && req.headers['x-forwarded-for'].split(',')[0].trim()) ||
    req.socket.remoteAddress;

  try {
    if (!username || !password) {
      return res.status(400).json({ success: false, message: 'Missing credentials.' });
    }

    // Accept either username or email in "username" field
    const query = /\S+@\S+\.\S+/.test(username)
      ? { email: username }
      : { username };

    const user = await User.findOne(query);
    if (!user) {
      await LoginAttempt.create({ username, ip, success: false });
      // Generic message to avoid user enumeration
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });
    }

    if (user.banned) {
      await LoginAttempt.create({ username, ip, success: false, userId: user._id });
      return res.status(403).json({ success: false, message: 'Account banned.' });
    }

    const ok = await bcrypt.compare(password, user.password);
    if (!ok) {
      await LoginAttempt.create({ username, ip, success: false, userId: user._id });
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });
    }

    const token = signToken(user._id);
    await LoginAttempt.create({ username, ip, success: true, userId: user._id });

    return res.status(200).json({
      success: true,
      message: 'Login successful.',
      user: sanitizeUser(user),
      token
    });
  } catch (err) {
    console.error('loginUser error:', err);
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// Forgot Password (non-enumerating)
exports.forgotPassword = async (req, res) => {
  try {
    const { email } = req.body || {};
    if (!email) {
      return res.status(400).json({ success: false, message: 'Email required.' });
    }

    const user = await User.findOne({ email });
    // Always return success to prevent revealing account existence
    if (!user) {
      return res.json({ success: true, message: 'If an account exists, a reset link has been sent.' });
    }

    const token = crypto.randomBytes(32).toString('hex');
    const expiry = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes
    user.resetToken = token;
    user.resetTokenExpiry = expiry;
    await user.save();

    const base = process.env.BASE_URL || 'http://localhost:5173';
    // Include email for convenience on the reset page (optional)
    const resetUrl = `${base}/Pages/reset-password.html?token=${encodeURIComponent(token)}&email=${encodeURIComponent(
      email
    )}`;

    const html = `
      <div style="background:#000;color:#fff;font-family:Segoe UI,Tahoma,Arial,sans-serif;padding:40px;border-radius:12px;max-width:600px;margin:auto;border:1px solid #ff0033;box-shadow:0 0 20px rgba(255,0,51,.4);">
        <h1 style="color:#ff0033;text-align:center;">🔐 Password Reset</h1>
        <p style="font-size:16px;color:#ccc;margin-top:24px;">
          Hello <strong>${user.username}</strong>,<br/><br/>
          We received a request to reset your account password.
          If you made this request, click the button below to set a new password.
        </p>
        <div style="text-align:center;margin:28px 0;">
          <a href="${resetUrl}" style="background:#ff0033;color:#fff;padding:12px 22px;border-radius:8px;font-weight:700;text-decoration:none;box-shadow:0 0 12px rgba(255,0,51,.5);">Reset My Password</a>
        </div>
        <p style="font-size:13px;color:#888;">
          This link is valid for <strong>15 minutes</strong>. If you did not request this, you can safely ignore this email.
        </p>
        <hr style="border:none;border-top:1px solid #222;margin:28px 0;" />
        <p style="text-align:center;font-size:12px;color:#666;">© ${new Date().getFullYear()} Arnox Cheats — All rights reserved.</p>
      </div>
    `;

    await sendEmail({
      to: email,
      subject: 'Password Reset',
      html
    });

    return res.json({ success: true, message: 'If an account exists, a reset link has been sent.' });
  } catch (err) {
    console.error('forgotPassword error:', err);
    return res.status(500).json({ success: false, message: 'Error sending email.' });
  }
};

// Reset Password
exports.resetPassword = async (req, res) => {
  try {
    const { token, email, newPassword } = req.body || {};
    if (!token || !email || !newPassword) {
      return res.status(400).json({ success: false, message: 'Missing fields.' });
    }
    if (String(newPassword).length < 8) {
      return res.status(400).json({ success: false, message: 'Password must be at least 8 characters.' });
    }

    const user = await User.findOne({
      email,
      resetToken: token,
      resetTokenExpiry: { $gt: new Date() }
    });

    if (!user) {
      return res.status(400).json({ success: false, message: 'Invalid or expired token.' });
    }

    user.password = await bcrypt.hash(newPassword, SALT_ROUNDS);
    user.resetToken = null;
    user.resetTokenExpiry = null;
    await user.save();

    return res.json({ success: true, message: 'Password updated successfully.' });
  } catch (err) {
    console.error('resetPassword error:', err);
    return res.status(500).json({ success: false, message: 'Error resetting password.' });
  }
};
// after finding user
if (user.banned) {
  await LoginAttempt.create({ username, ip, success: false, userId: user._id });
  return res.status(403).json({ success: false, message: 'Account is banned.' });
};
