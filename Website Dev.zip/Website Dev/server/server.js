// FILE: server.js (secure, deploy-ready)
'use strict';

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');
const helmet = require('helmet');
const compression = require('compression');
const cookieParser = require('cookie-parser');
const mongoSanitize = require('express-mongo-sanitize');
const hpp = require('hpp');
const rateLimit = require('express-rate-limit');

// Models + utils (used by webhook)
const License = require('./models/License');
const User = require('./models/User');
const sendEmail = require('./utils/sendEmail');

dotenv.config();

// ----- Required envs -----
if (!process.env.MONGO_URI || !process.env.JWT_SECRET) {
  console.error('❌ Missing environment variables (MONGO_URI or JWT_SECRET)');
  process.exit(1);
}

const PORT = Number(process.env.PORT || 8080);
const SELLAPP_SECRET = process.env.SELLAPP_SECRET;

// ----- App -----
const app = express();

// If you’re behind a proxy/CDN (Nginx, Cloudflare), keep this:
app.set('trust proxy', 1);

// ----- CORS (strict allowlist) -----
const corsAllow = (process.env.CORS_ALLOWLIST || 'http://127.0.0.1:5500,http://localhost:5500,https://arnoxcheats.store')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean);

const corsOptions = {
  origin: function (origin, cb) {
    if (!origin) return cb(null, true); // same-origin/curl/server-to-server
    if (corsAllow.includes(origin)) return cb(null, true);
    return cb(new Error('CORS: Origin not allowed'), false);
  },
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  credentials: true,
  allowedHeaders: ['Content-Type', 'Authorization'],
};
app.use(cors(corsOptions));

// ----- Security Headers (Helmet + CSP) -----
const connectAllow = ["'self'", ...corsAllow];

app.use(
  helmet({
    hsts: process.env.NODE_ENV === 'production'
      ? { maxAge: 15552000, includeSubDomains: true, preload: true }
      : false,
    noSniff: true,
    frameguard: { action: 'deny' },
    referrerPolicy: { policy: 'no-referrer' },
    crossOriginOpenerPolicy: { policy: 'same-origin' },
    crossOriginResourcePolicy: { policy: 'same-origin' },
  })
);

// ⚠️ You use inline <script> in many pages. Allow it here or switch to nonces.
app.use(
  helmet.contentSecurityPolicy({
    useDefaults: false,
    directives: {
      'default-src': ["'self'"],
      'base-uri': ["'self'"],
      'form-action': ["'self'"],
      'img-src': ["'self'", 'data:'],
      'style-src': ["'self'", "'unsafe-inline'"],
      'script-src': ["'self'", "'unsafe-inline'"], // <-- allows inline scripts you already have
      'connect-src': connectAllow,
      'frame-ancestors': ["'none'"],
      'object-src': ["'none'"],
    }
  })
);

// ----- Hygiene / performance -----
app.use(compression());
app.use(express.json({ limit: '512kb' })); // was 64kb
app.use(cookieParser());
app.use(mongoSanitize()); // blocks $ and . in keys (Mongo operator injection)
app.use(hpp());           // HTTP Parameter Pollution guard

// ----- Rate limits -----
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(globalLimiter);

const authLimiter = rateLimit({ windowMs: 10 * 60 * 1000, max: 50 });
const lowWebhookLimiter = rateLimit({ windowMs: 10 * 60 * 1000, max: 60 });

app.use('/api/auth/', authLimiter);
app.use('/api/admin/login', authLimiter);
app.use('/api/auth/forgot-password', rateLimit({ windowMs: 60 * 60 * 1000, max: 10 }));
app.use('/api/sellapp/', lowWebhookLimiter);

// ----- Static (for reset-password.html, nimda.html, etc.) -----
app.use(express.static(path.join(__dirname, 'public')));

// ----- Mongo -----
mongoose.set('strictQuery', true);
mongoose
  .connect(process.env.MONGO_URI, { autoIndex: process.env.NODE_ENV !== 'production' })
  .then(() => console.log('✅ MongoDB Connected'))
  .catch((err) => {
    console.error('❌ Mongo Error:', err);
    process.exit(1);
  });

// ----- Health endpoints -----
app.get('/healthz', (_req, res) => res.status(200).json({ ok: true }));
app.get('/readiness', (_req, res) => res.status(200).json({ ok: true }));

// ----- Routes -----
const stockRoutes = require('./routes/stock');
app.use('/api/stock', stockRoutes);

console.log('🛠 Loading auth route');
app.use('/api/auth', require('./routes/auth'));

console.log('🛠 Loading sellapp route');
app.use('/api/sellapp', require('./routes/sellapp'));

console.log('🛠 Loading admin route');
const adminRoutes = require('./routes/admin');
console.log('🧪 adminRoutes loaded:', Object.keys(adminRoutes));
app.use('/api/admin', adminRoutes.adminRouter);

// ----- Sell.app webhook (direct) -----
// If you add HMAC signature verification later, you may need raw body middleware.
app.post('/api/sellapp/webhook-direct', async (req, res) => {
  try {
    if (!SELLAPP_SECRET || req.headers['x-sellapp-secret'] !== SELLAPP_SECRET) {
      return res.status(403).json({ error: 'Forbidden: Invalid webhook secret' });
    }

    const { event, data } = req.body || {};
    if (event !== 'order.completed') {
      return res.status(200).json({ message: 'Ignored non-complete event' });
    }

    const email = data?.customer_email;
    const productName = data?.product_title?.toLowerCase().replace(/ /g, '-');
    const variant = data?.variant_name?.toLowerCase();

    if (!email || !productName || !variant) {
      return res.status(400).json({ error: 'Missing order info' });
    }

    const license = await License.findOneAndUpdate(
      { product: productName, variant, status: 'unused' },
      { status: 'used', assignedTo: email, assignedAt: new Date() },
      { new: true }
    );

    if (!license) {
      console.error('❌ No license available for this product:', productName, variant);
      return res.status(404).json({ error: 'License out of stock' });
    }

    // if an account exists, link license to user
    const user = await User.findOne({ email }).select('_id');
    if (user) {
      license.user = user._id;
      await license.save();
    }

    await sendEmail({
      to: email,
      subject: `Your License Key for ${data.product_title}`,
      text: `Thanks for purchasing ${data.product_title} (${variant})!\n\nYour license key: ${license.key}\n\nYou can also view it anytime in your account dashboard.`,
    });

    console.log(`✅ License ${license.key} sent to ${email}`);
    return res.status(200).json({ success: true });
  } catch (err) {
    console.error('❌ Webhook error:', err);
    return res.status(500).json({ error: 'Webhook internal error' });
  }
});

// ----- 404 -----
app.all('*', (req, res) => {
  console.warn(`⚠️ Unmatched route: ${req.method} ${req.originalUrl}`);
  res.status(404).json({ success: false, message: 'Not Found' });
});

// ----- Start -----
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT} (${process.env.NODE_ENV || 'development'})`);
});
