// middleware/authMiddleware.js
const jwt = require('jsonwebtoken');
const User = require('../models/User');

module.exports = async function authMiddleware(req, res, next) {
  // Expect Authorization: Bearer <token>
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.toLowerCase().startsWith('bearer ')) {
    return res.status(401).json({ success: false, message: 'Unauthorized: No token provided' });
  }

  try {
    // tolerate extra spaces
    const token = authHeader.split(' ')[1]?.trim();
    if (!token) {
      return res.status(401).json({ success: false, message: 'Unauthorized: Malformed Authorization header' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (!decoded?.id) {
      return res.status(401).json({ success: false, message: 'Unauthorized: Invalid token' });
    }

    // Minimal projection; avoid sending password or internal fields downstream
    const user = await User.findById(decoded.id)
      .select('_id username email banned')
      .lean();

    if (!user) {
      return res.status(401).json({ success: false, message: 'Unauthorized: User not found' });
    }

    if (user.banned) {
      return res.status(403).json({ success: false, message: 'Account banned' });
    }

    req.user = user; // attach sanitized user to request
    return next();
  } catch (err) {
    if (err && err.name === 'TokenExpiredError') {
      return res.status(401).json({ success: false, message: 'Token expired' });
    }
    console.error('❌ JWT verify error:', err?.message || err);
    return res.status(401).json({ success: false, message: 'Unauthorized: Invalid token' });
  }
};
