const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const License = require('../models/License');

dotenv.config();

function sanitize(value) {
  return value.toLowerCase().replace(/ /g, '-');
}

async function importLicenses(fileName, product, variant) {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ Connected to MongoDB');

    const filePath = path.join(__dirname, '../license_keys/', fileName);
    if (!fs.existsSync(filePath)) {
      console.error(`❌ File not found: ${filePath}`);
      return process.exit(1);
    }

    const keys = fs.readFileSync(filePath, 'utf-8')
      .split(/\r?\n/)
      .map(line => line.trim())
      .filter(line => line !== '');

    const sanitizedProduct = sanitize(product);
    const sanitizedVariant = sanitize(variant);

    const licenses = keys.map(key => ({
      key,
      product: sanitizedProduct,
      variant: sanitizedVariant,
      status: 'unused',
    }));

    await License.insertMany(licenses);
    console.log(`✅ Imported ${licenses.length} license(s) for "${sanitizedProduct}" (${sanitizedVariant})`);
    process.exit(0);
  } catch (err) {
    console.error('❌ Import error:', err);
    process.exit(1);
  }
}

// Usage: node tools/importLicenses.js <filename> <product> <variant>
const [,, fileName, product, variant] = process.argv;
if (!fileName || !product || !variant) {
  console.error('❌ Usage: node tools/importLicenses.js <filename> <product> <variant>');
  process.exit(1);
}

importLicenses(fileName, product, variant);
