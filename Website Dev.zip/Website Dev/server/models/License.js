// models/License.js
const mongoose = require('mongoose');

const normalizeLower = (v) =>
  typeof v === 'string' ? v.trim().toLowerCase() : v;
const normalizeEmail = (v) =>
  typeof v === 'string' ? v.trim().toLowerCase() : v;

const LicenseSchema = new mongoose.Schema(
  {
    key: { type: String, required: true, unique: true, trim: true },

    // We normalize product/variant to lowercase so queries are consistent
    product: {
      type: String,
      required: true,
      set: normalizeLower,
      trim: true,
      minlength: 1,
      maxlength: 120,
    },
    variant: {
      type: String,
      required: true,
      set: normalizeLower,
      trim: true,
      minlength: 1,
      maxlength: 120,
    },

    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },

    // If you use durations (week/month), we compute and store this
    expiresAt: { type: Date, default: null },

    // We currently use 'unused' and 'used' in routes; keep 'active' for future
    status: {
      type: String,
      enum: ['unused', 'active', 'used'],
      default: 'unused',
      index: true,
    },

    // Convenience for email-linked assignments (normalized)
    assignedTo: {
      type: String,
      set: normalizeEmail,
      trim: true,
      maxlength: 254,
    },
    assignedAt: { type: Date },
  },
  {
    timestamps: true, // createdAt, updatedAt
    versionKey: false,
  }
);

// 🔎 Indexes for fast lookups
LicenseSchema.index({ status: 1, product: 1, variant: 1 });   // stock & assignment
LicenseSchema.index({ user: 1, status: 1, assignedAt: -1 });  // dashboard queries
LicenseSchema.index({ assignedAt: -1 });                      // recent assignments
LicenseSchema.index({ product: 1, variant: 1 });              // general product views

module.exports = mongoose.model('License', LicenseSchema);
