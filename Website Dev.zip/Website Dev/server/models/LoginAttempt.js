// models/LoginAttempt.js
const mongoose = require('mongoose');

const loginAttemptSchema = new mongoose.Schema(
  {
    username: { type: String, trim: true, lowercase: true },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    ip: { type: String, trim: true, maxlength: 45 }, // IPv6 max length
    success: { type: Boolean, required: true },
    timestamp: { type: Date, default: Date.now },    // used for TTL + sorting
  },
  {
    timestamps: false, // we use 'timestamp' field instead
    versionKey: false,
  }
);

// Indexes for speed
loginAttemptSchema.index({ timestamp: -1 });
loginAttemptSchema.index({ userId: 1, timestamp: -1 });
loginAttemptSchema.index({ username: 1, timestamp: -1 });

// Auto-delete logs after 180 days (adjust as needed)
loginAttemptSchema.index({ timestamp: 1 }, { expireAfterSeconds: 60 * 60 * 24 * 180 });

module.exports = mongoose.model('LoginAttempt', loginAttemptSchema);
