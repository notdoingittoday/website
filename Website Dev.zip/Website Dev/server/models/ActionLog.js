// models/ActionLog.js
const mongoose = require('mongoose');

const safeStr = (v, max = 200) =>
  typeof v === 'string' ? v.trim().slice(0, max) : v;

const actionLogSchema = new mongoose.Schema(
  {
    admin:  { type: String, set: v => safeStr(v, 64),  required: true }, // e.g., 'admin'
    action: { type: String, set: v => safeStr(v, 200), required: true }, // e.g., 'Uploaded 5 keys'
    target: { type: String, set: v => safeStr(v, 200) },                 // e.g., userId/product|variant
    details:{ type: mongoose.Schema.Types.Mixed },                        // optional structured payload
  },
  {
    timestamps: { createdAt: true, updatedAt: false }, // auto createdAt
    versionKey: false,
  }
);

// 🔎 Indexes for fast admin views
actionLogSchema.index({ createdAt: -1 });
actionLogSchema.index({ admin: 1, createdAt: -1 });
actionLogSchema.index({ action: 1, createdAt: -1 });

// Optional TTL (auto-purge after 180 days). Uncomment if you want rotation:
// actionLogSchema.index({ createdAt: 1 }, { expireAfterSeconds: 60 * 60 * 24 * 180 });

module.exports = mongoose.model('ActionLog', actionLogSchema);
