// models/AdminLog.js
const mongoose = require('mongoose');

const safeStr = (v, max = 200) =>
  typeof v === 'string' ? v.trim().slice(0, max) : v;

const adminLogSchema = new mongoose.Schema(
  {
    // short string like "Changed email", "Banned user"
    action: { type: String, required: true, set: v => safeStr(v, 200) },

    // who performed it (e.g., "admin" or an admin username/id)
    admin:  { type: String, required: true, set: v => safeStr(v, 64) },

    // optional: direct reference to affected user
    targetUser: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },

    // optional: anything structured you want to attach (ids, before/after, etc.)
    details: { type: mongoose.Schema.Types.Mixed },
  },
  {
    timestamps: { createdAt: true, updatedAt: false }, // gives createdAt
    versionKey: false,
  }
);

// 🔎 indexes for quick admin pages
adminLogSchema.index({ createdAt: -1 });
adminLogSchema.index({ targetUser: 1, createdAt: -1 });
adminLogSchema.index({ action: 1, createdAt: -1 });

module.exports = mongoose.model('AdminLog', adminLogSchema);
