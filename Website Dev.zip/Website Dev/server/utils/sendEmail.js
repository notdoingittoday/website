// utils/sendEmail.js
const nodemailer = require('nodemailer');
const dotenv = require('dotenv');
dotenv.config();

// --- Basic sanity check for .env vars ---
['EMAIL_HOST', 'EMAIL_PORT', 'EMAIL_USER', 'EMAIL_PASS'].forEach((key) => {
  if (!process.env[key]) {
    console.warn(`⚠️ Missing env var: ${key}`);
  }
});

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: parseInt(process.env.EMAIL_PORT, 10) || 587,
  secure: parseInt(process.env.EMAIL_PORT, 10) === 465, // true for 465, false for others
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
  tls: {
    rejectUnauthorized: true, // prevent MITM
    minVersion: 'TLSv1.2',
  },
});

// Validate email format before attempting send
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

async function sendEmail({ to, subject, html }) {
  if (!isValidEmail(to)) {
    console.error(`❌ Invalid recipient email: ${to}`);
    throw new Error('Invalid email format');
  }

  try {
    // Optional: verify SMTP connection before sending
    await transporter.verify();
  } catch (err) {
    console.error('❌ SMTP connection failed:', err.message);
    throw new Error('SMTP server connection failed');
  }

  try {
    const info = await transporter.sendMail({
      from: `"Arnox Cheats" <${process.env.EMAIL_USER}>`,
      to,
      subject,
      html,
    });

    console.log(`📧 Email sent to ${to} | Message ID: ${info.messageId}`);
    return info;
  } catch (error) {
    console.error(`❌ Email sending failed to ${to}:`, error.message);
    throw error;
  }
}

module.exports = sendEmail;
