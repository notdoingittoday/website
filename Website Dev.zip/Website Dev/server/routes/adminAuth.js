// routes/adminAuth.js (hardened)
const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');

const LoginAttempt = require('../models/LoginAttempt');

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || '';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const ADMIN_JWT_SECRET = process.env.ADMIN_JWT_SECRET || '';

if (!ADMIN_JWT_SECRET) {
  console.warn('⚠️ ADMIN_JWT_SECRET is not defined in .env');
}

// --- helpers ---
const safeStr = (s, max = 256) => (typeof s === 'string' ? s.trim().slice(0, max) : '');
function timingSafeEqual(a, b) {
  const ab = Buffer.from(String(a), 'utf8');
  const bb = Buffer.from(String(b), 'utf8');
  if (ab.length !== bb.length) return false;
  return crypto.timingSafeEqual(ab, bb);
}

// --- rate limit for admin login (tunable) ---
const adminLoginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
});

// --- Admin login endpoint (only active if you mount this router) ---
router.post('/login', adminLoginLimiter, async (req, res) => {
  const username = safeStr(req.body?.username);
  const password = String(req.body?.password ?? '');
  const ip =
    (req.headers['x-forwarded-for'] && req.headers['x-forwarded-for'].split(',')[0].trim()) ||
    req.socket.remoteAddress;

  const okUser = timingSafeEqual(username, ADMIN_USERNAME);
  const okPass = timingSafeEqual(password, ADMIN_PASSWORD);
  const success = okUser && okPass;

  try {
    await LoginAttempt.create({ username, success, ip });
  } catch (err) {
    console.error('Failed to log admin login attempt:', err);
  }

  if (!ADMIN_USERNAME || !ADMIN_PASSWORD || !ADMIN_JWT_SECRET) {
    return res.status(500).json({ success: false, message: 'Admin not configured.' });
  }

  if (!success) {
    return res.status(401).json({ success: false, message: 'Invalid credentials' });
  }

  const token = jwt.sign({ isAdmin: true }, ADMIN_JWT_SECRET, { expiresIn: '6h' });
  return res.json({ success: true, token });
});

// --- Admin token verification middleware ---
function verifyAdminToken(req, res, next) {
  const authHeader = req.headers.authorization || '';
  if (!authHeader.toLowerCase().startsWith('bearer ')) {
    return res.status(401).json({ success: false, message: 'Authorization header missing or malformed' });
  }
  const token = authHeader.split(' ')[1]?.trim();
  if (!token) {
    return res.status(401).json({ success: false, message: 'Authorization header missing token' });
  }

  jwt.verify(token, ADMIN_JWT_SECRET, (err, decoded) => {
    if (err) {
      console.error('Admin JWT verification error:', err.message);
      return res.status(403).json({ success: false, message: 'Invalid or expired token' });
    }
    if (!decoded?.isAdmin) {
      return res.status(403).json({ success: false, message: 'Access denied: not an admin' });
    }
    req.admin = decoded;
    return next();
  });
}

module.exports = { adminRouter: router, verifyAdminToken };
