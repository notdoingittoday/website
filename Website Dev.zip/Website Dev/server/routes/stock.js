// routes/stock.js (real stock, public-safe)
const express = require('express');
const router = express.Router();
const License = require('../models/License');

// GET /api/stock
// Optional query params:
//   - product: exact match (case-insensitive)
//   - variant: exact match (case-insensitive)
router.get('/', async (req, res) => {
  try {
    const q = { status: 'unused' };

    // Optional filters
    if (req.query.product) q.product = String(req.query.product).toLowerCase().trim();
    if (req.query.variant) q.variant = String(req.query.variant).toLowerCase().trim();

    const licenses = await License.find(q)
      .select('product variant') // minimal fields
      .lean();

    const stock = {};
    for (const lic of licenses) {
      const product = (lic.product || '').toLowerCase();
      const variant = (lic.variant || '').toLowerCase();
      const key = `${product}|${variant}`;
      stock[key] = (stock[key] || 0) + 1;
    }

    // Public caching: 15s; adjust to taste or disable by removing these headers
    res.set({
      'Cache-Control': 'public, max-age=15',
      'Content-Type': 'application/json; charset=utf-8',
    });

    return res.json({ success: true, stock });
  } catch (err) {
    console.error('❌ stock route error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
