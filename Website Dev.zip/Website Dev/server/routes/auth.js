const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

const License = require('../models/License');
const authMiddleware = require('../middleware/authMiddleware');

const {
  registerUser,
  loginUser,
  forgotPassword,
  resetPassword
} = require('../controllers/authController');

/**
 * GET /api/auth/dashboard
 * Returns licenses linked to the authenticated user.
 * Auth: Bearer <JWT> (handled by authMiddleware)
 */
router.get('/dashboard', authMiddleware, async (req, res) => {
  try {
    const userId = req.user && req.user._id;

    if (!userId || !mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(400).json({ success: false, message: 'Invalid user id.' });
    }

    // Only expose what the dashboard actually needs
    const licenses = await License.find({ user: userId })
      .select('product variant key status assignedAt') // minimal surface
      .sort({ assignedAt: -1, _id: -1 })
      .lean();

    return res.status(200).json({ success: true, licenses });
  } catch (err) {
    console.error('❌ Dashboard error:', err);
    return res.status(500).json({ success: false, message: 'Dashboard fetch failed' });
  }
});

// Auth routes (kept identical to your frontend expectations)
router.post('/register', registerUser);
router.post('/login', loginUser);
router.post('/forgot-password', forgotPassword);
router.post('/reset-password', resetPassword);

module.exports = router;
