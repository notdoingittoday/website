// routes/sellapp.js (hardened)
const express = require('express');
const router = express.Router();
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');

const License = require('../models/License');
const User = require('../models/User');
const sendEmail = require('../utils/sendEmail');

const SELLAPP_SECRET = process.env.SELLAPP_SECRET || '';
const BASE_URL = process.env.BASE_URL || 'https://arnoxcheats.store';

// --- rate limit to protect webhook ---
const webhookLimiter = rateLimit({
  windowMs: 5 * 60 * 1000, // 5 minutes
  max: 300,                // tune as needed
  standardHeaders: true,
  legacyHeaders: false,
});

// helper: safe string and timing-safe compare
const safeStr = (s, max = 256) => (typeof s === 'string' ? s.trim().slice(0, max) : '');
function timingSafeEqual(a, b) {
  const ab = Buffer.from(String(a), 'utf8');
  const bb = Buffer.from(String(b), 'utf8');
  if (ab.length !== bb.length) return false;
  return crypto.timingSafeEqual(ab, bb);
}

// calculate expiry from a variant string
function calculateExpiry(variant) {
  const now = new Date();
  const v = (variant || '').toLowerCase();
  if (v.includes('week')) {
    now.setDate(now.getDate() + 7);
    return now;
  }
  if (v.includes('month')) {
    now.setMonth(now.getMonth() + 1);
    return now;
  }
  if (v.includes('lifetime') || v.includes('perm')) return null;
  return now; // default: immediate expiry (or adjust to null if you prefer)
}

// Parse Sell.app payload consistently
function parseSellAppPayload(body) {
  const event = safeStr(body?.event);

  // Newer style (order.*) payload from Sell.app
  if (event === 'order.completed' || event === 'order.created') {
    const data = body?.data || {};
    const email = safeStr(data?.customer_information?.email, 254);

    // Assumes the first variant is what we sell (typical single-item carts)
    const variantData = Array.isArray(data?.product_variants) ? data.product_variants[0] : null;
    const productName = safeStr(variantData?.product_title, 120);
    const variant = safeStr(variantData?.title, 120) || 'default';

    return { event, email, productName, variant, orderId: safeStr(data?.id, 64) };
  }

  // Legacy delivered event shape
  if (event === 'order.delivered') {
    const email = safeStr(body?.invoice?.customer_information?.email, 254);
    const productName = safeStr(body?.listing?.title, 120);
    const variant = safeStr(body?.variant?.title, 120) || 'default';
    const orderId = safeStr(body?.invoice?.id, 64);
    return { event, email, productName, variant, orderId };
  }

  return { event };
}

// --- webhook endpoint ---
router.post('/webhook', webhookLimiter, async (req, res) => {
  try {
    // 1) Check secret (timing-safe)
    const headerSecret = safeStr(req.headers['x-sellapp-secret'], 200);
    if (!SELLAPP_SECRET || !headerSecret || !timingSafeEqual(headerSecret, SELLAPP_SECRET)) {
      return res.status(403).json({ success: false, message: 'Forbidden: Invalid webhook secret' });
    }

    // 2) Parse payload
    const { event, email, productName, variant /*, orderId*/ } = parseSellAppPayload(req.body || {});
    if (!event) {
      return res.status(400).json({ success: false, message: 'Missing event' });
    }

    if (!email || !productName || !variant) {
      return res.status(400).json({
        success: false,
        message: 'Missing order information (email/product/variant)'
      });
    }

    // Normalize to match admin upload/store format
    const productKey = productName.toLowerCase();
    const variantKey = variant.toLowerCase();

    // 3) Make sure the user exists
    const user = await User.findOne({ email }).select('_id').lean();
    if (!user) {
      // If you want to auto-create users, we can add that — for now keep behavior consistent:
      return res.status(200).json({ success: true, message: 'User not found — skipping license assignment' });
    }

    // 4) Idempotency guard (avoid resending/assigning twice if Sell.app retries)
    //    Look for a recent used license for the same email+product+variant
    const alreadyAssigned = await License.findOne({
      user: user._id,
      product: productKey,
      variant: variantKey,
      status: 'used'
    })
      .select('_id key assignedAt')
      .sort({ assignedAt: -1 })
      .lean();

    if (alreadyAssigned) {
      // You could also decide to re-send the email here if you wish
      return res.status(200).json({ success: true, message: 'License already assigned' });
    }

    // 5) Pull an unused key and assign it
    const expiry = calculateExpiry(variantKey);
    const license = await License.findOneAndUpdate(
      { product: productKey, variant: variantKey, status: 'unused' },
      {
        status: 'used',
        assignedTo: email,
        assignedAt: new Date(),
        user: user._id,
        expiresAt: expiry
      },
      { new: true }
    );

    if (!license) {
      return res.status(404).json({ success: false, message: 'No licenses available for this product/variant' });
    }

    // 6) Send confirmation email
    const html = `
      <div style="background-color:#0d0d0d;padding:30px;color:#fff;font-family:Arial,sans-serif;border-radius:10px;border:1px solid #ff0033;max-width:600px;margin:auto;">
        <h2 style="color:#ff0033;text-align:center;">🎮 Your License is Ready!</h2>
        <p>Thank you for your purchase of <strong style="color:#ff0033;">${productName}</strong> (${variant}).</p>
        <p style="margin-top:20px;">Here is your license key:</p>
        <div style="background-color:#1a1a1a;padding:15px;border-radius:6px;font-size:18px;color:#00ff00;text-align:center;word-break:break-all;border:1px dashed #444;">
          ${license.key}
        </div>
        <p style="margin-top:20px;">This key is also stored safely in your <a href="${BASE_URL}/Pages/dashboard.html" style="color:#ff0033;text-decoration:underline;">account dashboard</a>.</p>
        <p style="margin-top:40px;">Need help? Join our <a href="https://discord.gg/vannia" style="color:#00bfff;text-decoration:underline;">Discord</a> for support.</p>
        <hr style="margin:30px 0;border:0;border-top:1px solid #222;" />
        <p style="font-size:13px;color:#888;text-align:center;">© ${new Date().getFullYear()} Arnox Cheats. For educational use only.</p>
      </div>
    `;
    await sendEmail({
      to: email,
      subject: `Your License Key for ${productName}`,
      html
    });

    return res.status(200).json({ success: true });
  } catch (err) {
    console.error('❌ Sell.app webhook error:', err);
    return res.status(500).json({ success: false, message: 'Webhook error' });
  }
});

module.exports = router;
