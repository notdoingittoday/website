// --- routes/admin.js (hardened) ---
const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const mongoose = require('mongoose');

const User = require('../models/User');
const License = require('../models/License');
const ActionLog = require('../models/ActionLog');
const LoginAttempt = require('../models/LoginAttempt');
const { verifyAdminToken } = require('./adminAuth');

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || '';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const ADMIN_JWT_SECRET = process.env.ADMIN_JWT_SECRET || '';
const SALT_ROUNDS = 12;

// Small helpers
const isObjectId = (v) => mongoose.Types.ObjectId.isValid(v);
const safeStr = (s, max = 256) => (typeof s === 'string' ? s.trim().slice(0, max) : '');

// Timing-safe equality for admin creds
function safeEqual(a, b) {
  const aBuf = Buffer.from(String(a), 'utf8');
  const bBuf = Buffer.from(String(b), 'utf8');
  if (aBuf.length !== bBuf.length) return false;
  return crypto.timingSafeEqual(aBuf, bBuf);
}

// Log admin actions
async function logAction(admin, action, target) {
  try {
    await ActionLog.create({
      admin: admin?.isAdmin ? 'admin' : 'unknown',
      action: safeStr(action, 200),
      target: safeStr(target, 200),
    });
  } catch (e) {
    console.error('ActionLog error:', e);
  }
}

// --- Admin login ---
router.post('/login', (req, res) => {
  try {
    const username = safeStr(req.body?.username);
    const password = String(req.body?.password ?? '');

    if (!username || !password) {
      return res.status(400).json({ success: false, message: 'Missing credentials.' });
    }
    if (!ADMIN_USERNAME || !ADMIN_PASSWORD || !ADMIN_JWT_SECRET) {
      return res.status(500).json({ success: false, message: 'Admin not configured.' });
    }

    // Constant-time compare (still plaintext-based env; consider hashing in future)
    const userOk = safeEqual(username, ADMIN_USERNAME);
    const passOk = safeEqual(password, ADMIN_PASSWORD);

    if (!userOk || !passOk) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    const token = jwt.sign({ isAdmin: true }, ADMIN_JWT_SECRET, { expiresIn: '6h' });
    return res.json({ success: true, token });
  } catch (err) {
    console.error('Admin login error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

// --- Verify token for frontend ---
router.get('/verify', verifyAdminToken, (req, res) => {
  return res.json({ success: true, admin: true });
});

// --- Search users ---
router.get('/users', verifyAdminToken, async (req, res) => {
  try {
    const q = safeStr(req.query.q, 100);
    if (!q) {
      return res.json({ success: true, users: [] });
    }

    const users = await User.find({
      $or: [
        { email: { $regex: q, $options: 'i' } },
        { username: { $regex: q, $options: 'i' } },
      ],
    })
      .select('_id username email banned createdAt')
      .limit(50)
      .lean();

    return res.json({ success: true, users });
  } catch (err) {
    console.error('Search users error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

// --- Change email ---
router.post('/change-email', verifyAdminToken, async (req, res) => {
  try {
    const userId = safeStr(req.body?.userId);
    const newEmail = safeStr(req.body?.newEmail, 254);

    if (!isObjectId(userId)) return res.status(400).json({ success: false, message: 'Invalid user id' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail)) {
      return res.status(400).json({ success: false, message: 'Invalid email' });
    }

    await User.findByIdAndUpdate(userId, { email: newEmail });
    await logAction(req.admin, 'Changed email', userId);
    return res.json({ success: true });
  } catch (err) {
    console.error('change-email error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

// --- Change password ---
router.post('/change-password', verifyAdminToken, async (req, res) => {
  try {
    const userId = safeStr(req.body?.userId);
    const newPassword = String(req.body?.newPassword ?? '');

    if (!isObjectId(userId)) return res.status(400).json({ success: false, message: 'Invalid user id' });
    if (newPassword.length < 8) {
      return res.status(400).json({ success: false, message: 'Password must be at least 8 characters.' });
    }

    const hashed = await bcrypt.hash(newPassword, SALT_ROUNDS);
    await User.findByIdAndUpdate(userId, { password: hashed });
    await logAction(req.admin, 'Changed password', userId);
    return res.json({ success: true });
  } catch (err) {
    console.error('change-password error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

// --- Change username ---
router.post('/change-username', verifyAdminToken, async (req, res) => {
  try {
    const userId = safeStr(req.body?.userId);
    const newUsername = safeStr(req.body?.newUsername, 20);

    if (!isObjectId(userId)) return res.status(400).json({ success: false, message: 'Invalid user id' });
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(newUsername)) {
      return res.status(400).json({ success: false, message: 'Username must be 3–20 characters (letters, numbers, _).' });
    }

    await User.findByIdAndUpdate(userId, { username: newUsername });
    await logAction(req.admin, 'Changed username', userId);
    return res.json({ success: true });
  } catch (err) {
    console.error('change-username error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

// --- Ban / Unban ---
router.post('/ban-user', verifyAdminToken, async (req, res) => {
  try {
    const userId = safeStr(req.body?.userId);
    if (!isObjectId(userId)) return res.status(400).json({ success: false, message: 'Invalid user id' });

    await User.findByIdAndUpdate(userId, { banned: true });
    await logAction(req.admin, 'Banned user', userId);
    return res.json({ success: true });
  } catch (err) {
    console.error('ban-user error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.post('/unban-user', verifyAdminToken, async (req, res) => {
  try {
    const userId = safeStr(req.body?.userId);
    if (!isObjectId(userId)) return res.status(400).json({ success: false, message: 'Invalid user id' });

    await User.findByIdAndUpdate(userId, { banned: false });
    await logAction(req.admin, 'Unbanned user', userId);
    return res.json({ success: true });
  } catch (err) {
    console.error('unban-user error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

// --- Delete license ---
router.post('/delete-license', verifyAdminToken, async (req, res) => {
  try {
    const licenseId = safeStr(req.body?.licenseId);
    if (!isObjectId(licenseId)) return res.status(400).json({ success: false, message: 'Invalid license id' });

    await License.findByIdAndDelete(licenseId);
    await logAction(req.admin, 'Deleted license', licenseId);
    return res.json({ success: true });
  } catch (err) {
    console.error('delete-license error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

// --- Upload license keys ---
router.post('/upload-license', verifyAdminToken, async (req, res) => {
  try {
    const rawKeys = Array.isArray(req.body?.keys) ? req.body.keys : null;
    const product = safeStr(req.body?.product, 80).toLowerCase();
    const variant = safeStr(req.body?.variant, 80).toLowerCase();

    if (!rawKeys) return res.status(400).json({ success: false, message: 'Keys missing' });
    if (!product || !variant) return res.status(400).json({ success: false, message: 'Product/variant required' });

    // Clean keys: trim, remove blanks, dedupe
    const keys = [...new Set(rawKeys.map(k => safeStr(k, 200)).filter(Boolean))];
    if (keys.length === 0) return res.status(400).json({ success: false, message: 'No valid keys' });

    const docs = keys.map(key => ({ key, product, variant, status: 'unused' }));

    let inserted = 0;
    try {
      const result = await License.insertMany(docs, { ordered: false });
      inserted = result?.length || 0;
    } catch (e) {
      // Duplicate keys or partial failures: count what made it
      if (e?.insertedDocs) inserted = e.insertedDocs.length;
      else if (Array.isArray(e?.result?.result?.nInserted)) inserted = e.result.result.nInserted;
    }

    await logAction(req.admin, `Uploaded ${inserted} keys`, `${product}-${variant}`);
    return res.json({ success: true, added: inserted });
  } catch (err) {
    console.error('upload-license error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

// --- Admin logs ---
router.get('/logs', verifyAdminToken, async (req, res) => {
  try {
    const logs = await ActionLog.find({})
      .select('admin action target createdAt')
      .sort({ createdAt: -1, _id: -1 })
      .limit(100)
      .lean();
    return res.json({ success: true, logs });
  } catch (err) {
    console.error('logs error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

// --- Licenses per user ---
router.get('/user-licenses/:userId', verifyAdminToken, async (req, res) => {
  try {
    const userId = safeStr(req.params.userId);
    if (!isObjectId(userId)) return res.status(400).json({ success: false, message: 'Invalid user id' });

    const licenses = await License.find({ user: userId })
      .select('product variant key status assignedAt')
      .sort({ assignedAt: -1, _id: -1 })
      .lean();

    return res.json({ success: true, licenses });
  } catch (err) {
    console.error('user-licenses error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

// --- All licenses grouped ---
router.get('/all-licenses', verifyAdminToken, async (req, res) => {
  try {
    const all = await License.find({})
      .select('product variant status user assignedAt')
      .lean();

    const grouped = {};
    for (const lic of all) {
      const k = `${lic.product}|${lic.variant}`;
      if (!grouped[k]) grouped[k] = [];
      grouped[k].push(lic);
    }
    return res.json({ success: true, grouped });
  } catch (err) {
    console.error('all-licenses error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

// --- Public stock endpoint (no auth) ---
router.get('/stock', async (req, res) => {
  try {
    const licenses = await License.find({ status: 'unused' }).select('product variant').lean();
    const stock = {};
    for (const lic of licenses) {
      const k = `${lic.product}|${lic.variant}`;
      stock[k] = (stock[k] || 0) + 1;
    }
    return res.json({ success: true, stock });
  } catch (err) {
    console.error('stock error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

// --- Login attempts (latest 100) ---
router.get('/login-attempts', verifyAdminToken, async (req, res) => {
  try {
    const attempts = await LoginAttempt.find({})
      .select('username ip success timestamp userId')
      .sort({ timestamp: -1, _id: -1 })
      .limit(100)
      .lean();

    return res.json({ success: true, attempts });
  } catch (err) {
    console.error('login-attempts error:', err);
    return res.status(500).json({ success: false, message: 'Error retrieving login attempts.' });
  }
});

module.exports = {
  adminRouter: router,
};
