"use strict";

console.log("✅ validation.js connected");

// Basic sanitize + trim (frontend validation only; backend still must sanitize)
function sanitizeInput(input) {
  const temp = document.createElement("div");
  temp.textContent = (input || "").trim();
  return temp.innerHTML;
}

function isEmailValid(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

function isUsernameValid(username) {
  const re = /^[a-zA-Z0-9_]{3,20}$/;
  return re.test(username);
}

// Strength: 8+ chars, at least one letter and one number
function isPasswordStrong(password) {
  if (!password || password.length < 8) return false;
  const hasLetter = /[A-Za-z]/.test(password);
  const hasNumber = /\d/.test(password);
  return hasLetter && hasNumber;
}

// Real-time password match check (only when repeat field is visible)
document.addEventListener("input", () => {
  const pass = document.getElementById("password");
  const repeat = document.getElementById("repeatPassword");
  const errorDiv = document.getElementById("repeatPasswordError");

  if (!pass || !repeat || !errorDiv) return;
  // Skip when the repeat field is hidden (e.g., Login mode)
  const repeatHidden = repeat.offsetParent === null;
  if (repeatHidden) return;

  if (pass.value && repeat.value && pass.value !== repeat.value) {
    errorDiv.textContent = "Passwords do not match.";
  } else {
    errorDiv.textContent = "";
  }
});

// Local, non-global clear to avoid colliding with index.html’s clearErrors()
const clearFormErrors = () => {
  ["usernameError", "emailError", "passwordError", "repeatPasswordError"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = "";
  });
};

function showErrors(errors) {
  errors.forEach(msg => {
    const lower = msg.toLowerCase();
    let targetId = "passwordError";
    if (lower.includes("username")) targetId = "usernameError";
    else if (lower.includes("email")) targetId = "emailError";
    else if (lower.includes("repeat")) targetId = "repeatPasswordError";

    const el = document.getElementById(targetId);
    if (el) el.textContent = msg;
  });
}

// Exposed validator used by your inline script
function validateForm(mode) {
  clearFormErrors();

  const username = sanitizeInput(document.getElementById("username")?.value);
  const password = document.getElementById("password")?.value || "";
  const email = sanitizeInput(document.getElementById("email")?.value);
  const repeatPassword = document.getElementById("repeatPassword")?.value || "";

  const errors = [];

  if (!username) {
    errors.push("Username is required.");
  } else if (!isUsernameValid(username)) {
    errors.push("Username must be 3–20 characters and can include letters, numbers, and underscores.");
  }

  if (!password) {
    errors.push("Password is required.");
  } else if (!isPasswordStrong(password)) {
    errors.push("Password must be at least 8 characters and include a letter and a number.");
  }

  if (mode === "Register") {
    if (!email || !isEmailValid(email)) {
      errors.push("Please enter a valid email.");
    }
    if (!repeatPassword) {
      errors.push("Repeat password is required.");
    } else if (password !== repeatPassword) {
      errors.push("Passwords do not match.");
    }
  }

  if (errors.length) {
    showErrors(errors);
    return false;
  }
  return true;
}

// Make sure your inline code can call it
window.validateForm = validateForm;
